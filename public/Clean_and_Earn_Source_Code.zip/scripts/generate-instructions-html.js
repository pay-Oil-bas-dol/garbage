const fs = require('fs');
const path = require('path');

const baseDir = path.resolve(__dirname, '..');

const masterPromptText = `Execute the complete, autonomous multi-agent development replay of Clean & Earn (SafaiSaathi). 

You are the Lead Coordinator of an Autonomous Swarm of 9 Specialized Subagents:
1. 🏛️ System Architect & Team Lead (System decomposition & Swachh Bharat requirements)
2. 🎨 Frontend UI/UX Specialist (Next.js 16 App Router, React 19, mobile shell & Tailwind CSS)
3. 🗄️ Database & Cloud Engineer (Supabase PostgreSQL schema, RLS policies & SQL point triggers)
4. 🤖 Computer Vision AI Specialist (Google Gemini 1.5 Flash Vision route & JSON guardrails)
5. 🛡️ Anti-Fraud & Heuristics QA Engineer (Built-in neural-verifier & landmark verification)
6. 📍 Geospatial & Hardware Integration Engineer (HTML5 Geolocation & mobile camera capture)
7. 🏆 Gamification & Economics Designer (Green Points 20-50 pts, ledger & leaderboards)
8. 🚀 DevOps & Edge Deployment Lead (Vercel global edge network & build pipelines)
9. 📑 Documentation & Presentation Specialist (18-slide deck with Pan/Zoom Mermaid diagrams)

Please automatically and continuously progress through all project development milestones from start to finish without pausing or waiting for my intervention. For each milestone:
1. Display the Prompt as if received from me.
2. Coordinate the specialized subagents to provide their architectural decisions, code implementation, tool calls, and test results.
3. Automatically advance to the next prompt in sequence until all 18 milestones, the 18-slide interactive presentation deck, user flow diagrams, and production deployment are fully presented.
Begin immediately with Milestone 1.`;

const html = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Clean &amp; Earn — Cousin Instructions &amp; Auto-Replay</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet">
  <style>
    body { font-family: 'Plus Jakarta Sans', sans-serif; }
    pre, code, .font-mono { font-family: 'JetBrains Mono', monospace; }
  </style>
</head>
<body class="bg-slate-950 text-slate-100 min-h-screen flex flex-col justify-between">

  <!-- Header -->
  <header class="bg-slate-900 border-b border-slate-800 sticky top-0 z-50 px-6 py-4 flex items-center justify-between shadow-xl">
    <div class="flex items-center space-x-3">
      <div class="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-700 flex items-center justify-center text-xl font-bold text-white shadow-lg shadow-emerald-950/50">
        🚀
      </div>
      <div>
        <h1 class="text-base font-bold text-white tracking-tight flex items-center gap-2">
          Clean &amp; Earn (SafaiSaathi)
          <span class="bg-emerald-500/20 text-emerald-400 text-xs px-2 py-0.5 rounded-full font-mono font-medium border border-emerald-500/30">Cousin Guide</span>
        </h1>
        <p class="text-xs text-slate-400">One-Shot Autonomous Antigravity Replay Instructions</p>
      </div>
    </div>
    <div class="flex items-center space-x-3 text-xs">
      <a href="multi_agent_replay.html" class="bg-slate-800 hover:bg-slate-700 text-emerald-300 px-3.5 py-1.5 rounded-lg border border-slate-700 font-semibold transition-colors">
        🐝 Web Swarm Replay ↗
      </a>
      <a href="presentation.html" class="bg-emerald-600 hover:bg-emerald-500 text-white px-3.5 py-1.5 rounded-lg font-semibold transition-colors shadow">
        📊 18-Slide Presentation ↗
      </a>
    </div>
  </header>

  <!-- Main Instructions Container -->
  <main class="max-w-4xl w-full mx-auto p-4 sm:p-8 space-y-8 flex-1">
    
    <!-- Hero Box -->
    <div class="bg-gradient-to-br from-emerald-950/60 via-slate-900 to-slate-900 p-6 sm:p-8 rounded-3xl border border-emerald-500/30 shadow-2xl space-y-4">
      <div class="inline-flex items-center space-x-2 bg-emerald-500/10 border border-emerald-500/30 px-3 py-1 rounded-full text-emerald-300 text-xs font-semibold uppercase tracking-wider">
        <span>⚡ 1-Step Setup Guide</span>
      </div>
      <h2 class="text-2xl sm:text-3xl font-black text-white">How to Run the Automatic Demo for Your Professors</h2>
      <p class="text-sm text-slate-300 leading-relaxed">
        When you open this project in your Antigravity workspace, you only need to paste <strong>ONE MASTER PROMPT</strong>. Antigravity will automatically simulate the entire 18-milestone development process, dispatch tasks across <strong>9 specialized AI agents</strong>, and construct the project from scratch without you having to type anything again!
      </p>
    </div>

    <!-- The Master Prompt Card -->
    <div class="bg-slate-900 rounded-3xl border border-slate-800 shadow-2xl p-6 sm:p-8 space-y-4">
      <div class="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-800">
        <div>
          <span class="text-xs font-bold uppercase tracking-wider text-emerald-400 block">Step 1 — The Master Prompt</span>
          <h3 class="text-lg font-bold text-white">Copy &amp; Paste this into Antigravity Chat</h3>
        </div>
        <button id="copyBtn" onclick="copyMasterPrompt()" class="bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs px-4 py-2 rounded-xl transition-all shadow-md flex items-center space-x-2 active:scale-95">
          <span>📋</span>
          <span id="copyBtnText">Copy Master Prompt</span>
        </button>
      </div>

      <div class="relative bg-slate-950 rounded-2xl p-4 sm:p-5 border border-slate-800/80">
        <pre id="promptCode" class="text-xs sm:text-sm text-emerald-300 font-mono leading-relaxed whitespace-pre-wrap">${masterPromptText}</pre>
      </div>

      <p class="text-xs text-slate-400">
        💡 <strong>Tip:</strong> Click the button above to copy the prompt, open a new chat in Antigravity, paste it, and press Enter. That's it!
      </p>
    </div>

    <!-- What Happens Next (Timeline) -->
    <div class="bg-slate-900 rounded-3xl border border-slate-800 p-6 sm:p-8 space-y-5">
      <span class="text-xs font-bold uppercase tracking-wider text-teal-400 block">Step 2 — Automatic Swarm Execution</span>
      <h3 class="text-lg font-bold text-white">What You &amp; Your Professor Will Watch</h3>

      <div class="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
        <div class="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-1.5">
          <span class="text-emerald-400 font-bold block text-sm">1. Prompt Enters</span>
          <p class="text-slate-300">Antigravity outputs your initial request as if you just asked it, starting with Milestone 1.</p>
        </div>
        <div class="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-1.5">
          <span class="text-teal-400 font-bold block text-sm">2. 9 Agents Respond</span>
          <p class="text-slate-300">Architect, Frontend, Database, Vision AI, QA, Geospatial, Gamification, DevOps, and Docs collaborate in order.</p>
        </div>
        <div class="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-1.5">
          <span class="text-blue-400 font-bold block text-sm">3. Auto-Next</span>
          <p class="text-slate-300">Automatically moves to the next milestone until the full 18-slide deck, code, and live Vercel app are finished.</p>
        </div>
      </div>
    </div>

    <!-- Quick Terminal & Web Alternatives -->
    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
      <div class="bg-slate-900 p-6 rounded-3xl border border-slate-800 space-y-3">
        <span class="text-xs font-bold uppercase text-amber-400 block">Option B — Terminal Replay</span>
        <h4 class="font-bold text-white text-base">Watch Live in Command Prompt</h4>
        <p class="text-xs text-slate-400">Run this command in the terminal to watch the swarm print each step live with realistic typing delays:</p>
        <div class="bg-slate-950 p-3 rounded-xl border border-slate-800 text-xs font-mono text-emerald-400">
          node scripts/replicate-multi-agent-session.js --auto
        </div>
      </div>

      <div class="bg-slate-900 p-6 rounded-3xl border border-slate-800 space-y-3">
        <span class="text-xs font-bold uppercase text-indigo-400 block">Option C — Web Browser UI</span>
        <h4 class="font-bold text-white text-base">Open in Chrome or Edge</h4>
        <p class="text-xs text-slate-400">Open the interactive web visualizer with avatars, clickable prompts, and live previews:</p>
        <a href="multi_agent_replay.html" class="inline-flex items-center space-x-2 bg-slate-800 hover:bg-slate-700 text-emerald-300 border border-slate-700 px-4 py-2 rounded-xl text-xs font-bold transition-colors">
          <span>🐝 Open Multi-Agent Web Replay ↗</span>
        </a>
      </div>
    </div>

  </main>

  <!-- Footer -->
  <footer class="bg-slate-900 border-t border-slate-800 px-6 py-4 text-center text-xs text-slate-500 font-mono">
    Clean &amp; Earn (SafaiSaathi) • Complete College Demonstration Kit • Prepared for Antigravity Workspace
  </footer>

  <script>
    function copyMasterPrompt() {
      const code = document.getElementById('promptCode').innerText;
      navigator.clipboard.writeText(code).then(() => {
        const btnText = document.getElementById('copyBtnText');
        btnText.innerText = 'Copied to Clipboard! ✓';
        setTimeout(() => {
          btnText.innerText = 'Copy Master Prompt';
        }, 3000);
      });
    }
  </script>
</body>
</html>
`;

fs.writeFileSync(path.join(baseDir, 'COUSIN_INSTRUCTIONS.html'), html, 'utf8');
fs.writeFileSync(path.join(baseDir, 'public', 'COUSIN_INSTRUCTIONS.html'), html, 'utf8');

console.log('Successfully generated HTML instruction files:');
console.log('1. C:\\Users\\ceohr\\Downloads\\garbage\\COUSIN_INSTRUCTIONS.html');
console.log('2. C:\\Users\\ceohr\\Downloads\\garbage\\public\\COUSIN_INSTRUCTIONS.html');
